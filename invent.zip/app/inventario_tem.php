<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inventario_tem extends Model
{
	
	 const UPDATED_AT = null;
   protected $table=('llx_inventary_temp');
    public $timestamps = false;
}
