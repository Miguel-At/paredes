<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reportes extends Model
{
  	const UPDATED_AT = null;
   protected $table=('llx_ reports');
   public $timestamps = false; 
}
