@extends('layouts.app')


@section('content')


<br>  
 
<div >
  <hr> 

<h5 id="r" >  Reportes </h5>


<form class="form-inline" id="pdf"  enctype="multipart/formdata">
  {{csrf_field()}}
   <div class="form-group mb-2">
   <select name="select_almacen" required="" class="form-control custom-select" id="select_almacen">
   <option selected="" >Selecciona un Almacen</option>
  @foreach($almacenes as $almacen)
  <option value="{{$almacen->rowid}}">{{$almacen->lieu}}</option>
  @endforeach
  </select>
   </div>
    <div class="form-group mx-sm-5 mb-2">
<button id="checar" class="btn btn-outline-primary" type="submit">Ver Reportes   </button>
    </div>


    <div class="form-group mx-5 mb-2"> 
     <button class="btn btn-outline-info" id="boton">Generar Reporte   </button>
    </div>

    <div class="loader form-group mx-5 mb-2" id="imgnone" >
        <img id="loadimg" src="{{asset('imagenes/loading.gif')}}" style=" width: 60px;
    height: 60px; border-image: 50px; border-radius: 50px;">
    </div>
</form>
<hr>
</div>


<div id="ocultar"  >
	<table id="tabla" class="table table-striped">
		<thead  >
			<tr>

				<th>Fecha del Reporte</th>
				<th>Ver Reporte</th>
			
			</tr>
		</thead>

		<tbody>
			@foreach($reportes as $r)
			<tr>
        <td>{{$r->almacen}}</td>
			<td>{{$r->fecha}}</td>
			<td><a  class="btn btn-outline-secondary" 
        target="_blank" href="{{url('mostrar').'/'.$r->report}}">    <i class="fas fa-file-pdf"> </i> </a ></td>
			
			</tr>
			
			@endforeach
		</tbody>
	</table>
</div>
@endsection()

@section('scripts')
<script>




     

$('#boton').on('click',function(e){
  e.preventDefault();
  var valor=$("#select_almacen").val();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
$.ajax({
       type:'POST',
       url:'{{url('reporte.pdf')}}',
       data:$('#pdf').serialize(),
       beforeSend:function(){
       $('.loader').show();
       $('#boton').text("Generenado reporte espere");
       $("#boton").prop("disabled", true);
       },
       success:function(response){
        console.log(response);
       if (response==1) {
          $('.loader').hide();
          $("#boton").prop("disabled", false);
        alert("no hay articulos en el conteo del almacen seleccionado");

       } else if(response==2) {
        alert("reporte generado");
          $('.loader').hide();
        $("#pdf").submit();
       }else if(response==3){
        alert("reporte actualizado");
        $('.loader').hide();
        $("#pdf").submit();
       }
       },
       error:function(error){
       console.log(error);
       alert('Error intente mas tarde ');
       }
       });
});

/*


       

        if (response==2) {

       
        alert("reporte generado");

        $("#pdf2").submit();
       } else if(response==3){
         alert("Reporte Actualizado");
        $("#pdf2").submit();
       }else{
          $("#pdf2").submit();
       }
     
    

*/
//url:'http://localhost:8080/invent/public/reporte.pdf',

</script>
@endsection()