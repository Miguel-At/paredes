@extends('layouts.app2')

@section('title','Almacen')
@section('content')


<div class="row">
<div class="col-md-4 offset-md-4">
	
<div class="card card-default">
	
<div class="card-heading">
	
<h3 class="card-title text-center">  Selecciona un almacen</h3>
<hr>

</div>


<div class="card-body">
	
<form action="{{url('almacen')}}" method="post" name="f" enctype="multipart/formdata">
{{csrf_field()}}
<select name="select_almacen" class="form-control" id="">
	 <option disabled selected value="">Selecciona una opción</option>
	@foreach($almacenes as $almacen)
	<option value="{{$almacen->rowid}}">{{$almacen->lieu}}</option>
	@endforeach

</select>

<br>
<button class=" btn btn-primary btn-block">Empezar</button>

</form>
</div>
</div>
</div>
</div>
 @endsection()