<?php $__env->startSection('title','Almacen'); ?>
<?php $__env->startSection('content'); ?>


<div class="row">
<div class="col-md-4 offset-md-4">
	
<div class="card card-default">
	
<div class="card-heading">
	
<h3 class="card-title text-center">  Selecciona un almacen</h3>
<hr>

</div>


<div class="card-body">
	
<form action="<?php echo e(url('almacen')); ?>" method="post" name="f" enctype="multipart/formdata">
<?php echo e(csrf_field()); ?>

<select name="select_almacen" class="form-control" id="">
	 <option disabled selected value="">Selecciona una opción</option>
	<?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($almacen->rowid); ?>"><?php echo e($almacen->lieu); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>

<br>
<button class=" btn btn-primary btn-block">Empezar</button>

</form>
</div>
</div>
</div>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invent\resources\views/store.blade.php ENDPATH**/ ?>