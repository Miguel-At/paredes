<?php $__env->startSection('content'); ?>


<br>  
 
<div >
  <hr> 

<h5 id="r" >  Reportes </h5>


<form class="form-inline" id="pdf"  enctype="multipart/formdata">
  <?php echo e(csrf_field()); ?>

   <div class="form-group mb-2">
   <select name="select_almacen" required="" class="form-control custom-select" id="select_almacen">
   <option selected="" >Selecciona un Almacen</option>
  <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($almacen->rowid); ?>"><?php echo e($almacen->lieu); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
   </div>
    <div class="form-group mx-sm-5 mb-2">
<button id="checar" class="btn btn-outline-primary" type="submit">Ver Reportes   </button>
    </div>


    <div class="form-group mx-5 mb-2"> 
     <button class="btn btn-outline-info" id="boton">Generar Reporte   </button>
    </div>

    <div class="loader form-group mx-5 mb-2" id="imgnone" >
        <img id="loadimg" src="<?php echo e(asset('imagenes/loading.gif')); ?>" style=" width: 60px;
    height: 60px; border-image: 50px; border-radius: 50px;">
    </div>
</form>
<hr>
</div>


<div id="ocultar"  >
	<table id="tabla" class="table table-striped">
		<thead  >
			<tr>

				<th>Fecha del Reporte</th>
				<th>Ver Reporte</th>
			
			</tr>
		</thead>

		<tbody>
			<?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
        <td><?php echo e($r->almacen); ?></td>
			<td><?php echo e($r->fecha); ?></td>
			<td><a  class="btn btn-outline-secondary" 
        target="_blank" href="<?php echo e(url('mostrar').'/'.$r->report); ?>">    <i class="fas fa-file-pdf"> </i> </a ></td>
			
			</tr>
			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>




     

$('#boton').on('click',function(e){
  e.preventDefault();
  var valor=$("#select_almacen").val();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
$.ajax({
       type:'POST',
       url:'<?php echo e(url('reporte.pdf')); ?>',
       data:$('#pdf').serialize(),
       beforeSend:function(){
       $('.loader').show();
       $('#boton').text("Generenado reporte espere");
       $("#boton").prop("disabled", true);
       },
       success:function(response){
        console.log(response);
       if (response==1) {
          $('.loader').hide();
          $("#boton").prop("disabled", false);
        alert("no hay articulos en el conteo del almacen seleccionado");

       } else if(response==2) {
        alert("reporte generado");
          $('.loader').hide();
        $("#pdf").submit();
       }else if(response==3){
        alert("reporte actualizado");
        $('.loader').hide();
        $("#pdf").submit();
       }
       },
       error:function(error){
       console.log(error);
       alert('Error intente mas tarde ');
       }
       });
});

/*


       

        if (response==2) {

       
        alert("reporte generado");

        $("#pdf2").submit();
       } else if(response==3){
         alert("Reporte Actualizado");
        $("#pdf2").submit();
       }else{
          $("#pdf2").submit();
       }
     
    

*/
//url:'http://localhost:8080/invent/public/reporte.pdf',

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invent\resources\views/productos/reportes.blade.php ENDPATH**/ ?>